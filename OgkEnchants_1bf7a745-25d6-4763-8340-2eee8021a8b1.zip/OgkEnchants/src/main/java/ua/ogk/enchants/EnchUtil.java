package ua.ogk.enchants;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;

public final class EnchUtil {
    private static Plugin plugin;
    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V"};

    private EnchUtil() {}

    public static void init(Plugin p) {
        plugin = p;
    }

    private static NamespacedKey key(Ench e) {
        return new NamespacedKey(plugin, e.id);
    }

    public static String roman(int n) {
        return n >= 1 && n < ROMAN.length ? ROMAN[n] : String.valueOf(n);
    }

    public static int level(ItemStack it, Ench e) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return 0;
        Integer v = it.getItemMeta().getPersistentDataContainer().get(key(e), PersistentDataType.INTEGER);
        return v == null ? 0 : v;
    }

    public static int armorLevel(LivingEntity le, Ench e) {
        EntityEquipment eq = le.getEquipment();
        if (eq == null) return 0;
        int best = 0;
        for (ItemStack a : eq.getArmorContents()) best = Math.max(best, level(a, e));
        return best;
    }

    private static boolean isOurLine(String plain) {
        for (Ench e : Ench.values()) {
            for (int l = 1; l <= e.max; l++) {
                if (plain.equals(e.display + " " + roman(l))) return true;
            }
        }
        return false;
    }

    /** Ставить рівень (0 = зняти) і перебудовує lore. */
    public static void set(ItemStack it, Ench e, int lvl) {
        ItemMeta meta = it.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        if (lvl <= 0) pdc.remove(key(e));
        else pdc.set(key(e), PersistentDataType.INTEGER, lvl);

        List<Component> out = new ArrayList<>();
        List<Component> old = meta.lore();
        if (old != null) {
            for (Component c : old) {
                if (!isOurLine(PlainTextComponentSerializer.plainText().serialize(c))) out.add(c);
            }
        }
        for (Ench x : Ench.values()) {
            int l = pdc.getOrDefault(key(x), PersistentDataType.INTEGER, 0);
            if (l > 0) {
                out.add(LegacyComponentSerializer.legacyAmpersand()
                        .deserialize("&7" + x.display + " " + roman(l))
                        .decoration(TextDecoration.ITALIC, false));
            }
        }
        meta.lore(out.isEmpty() ? null : out);
        it.setItemMeta(meta);
    }
}
