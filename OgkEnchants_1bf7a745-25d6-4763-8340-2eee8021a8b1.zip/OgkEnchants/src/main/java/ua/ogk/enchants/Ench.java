package ua.ogk.enchants;

import org.bukkit.Material;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Set;

public enum Ench {
    OGKUSHENYA("ogkushenya", "Оглушення", 3, "меч, сокира, булава", Kind.SWORD, Kind.AXE, Kind.MACE),
    BUR("bur", "Бур", 1, "кирка, лопата", Kind.PICKAXE, Kind.SHOVEL),
    DOSVID("dosvid", "Фермер досвіду", 3, "меч, сокира, булава", Kind.SWORD, Kind.AXE, Kind.MACE),
    DROVOSEK("drovosek", "Дровосек", 1, "сокира", Kind.AXE),
    AVTOPLAVKA("avtoplavka", "Автоплавка", 1, "кирка, сокира, лопата", Kind.PICKAXE, Kind.AXE, Kind.SHOVEL),
    FERMER("fermer", "Фермер", 3, "мотика", Kind.HOE),
    LAVOHID("lavohid", "Лавохід", 2, "чоботи", Kind.BOOTS),
    KRUSHYTEL("krushytel", "Крушитель", 3, "меч, сокира, булава", Kind.SWORD, Kind.AXE, Kind.MACE),
    KARATEL("karatel", "Каратель", 2, "меч, сокира, булава", Kind.SWORD, Kind.AXE, Kind.MACE),
    MAGNIT("magnit", "Магніт", 1, "кирка, сокира, лопата, мотика", Kind.PICKAXE, Kind.AXE, Kind.SHOVEL, Kind.HOE),
    STAL("stal", "Сталь", 2, "будь-яка броня", Kind.HELMET, Kind.CHESTPLATE, Kind.LEGGINGS, Kind.BOOTS),
    POTUZHNIST("potuzhnist", "Потужність", 3, "булава", Kind.MACE),
    STRUS("strus", "Струс", 1, "булава", Kind.MACE);

    public enum Kind { PICKAXE, AXE, SHOVEL, HOE, SWORD, MACE, HELMET, CHESTPLATE, LEGGINGS, BOOTS, OTHER }

    public final String id;
    public final String display;
    public final int max;
    public final String hint;
    private final Set<Kind> kinds;

    Ench(String id, String display, int max, String hint, Kind... kinds) {
        this.id = id;
        this.display = display;
        this.max = max;
        this.hint = hint;
        this.kinds = EnumSet.copyOf(Arrays.asList(kinds));
    }

    public boolean valid(Material m) {
        return kinds.contains(kindOf(m));
    }

    public static Ench byId(String id) {
        for (Ench e : values()) if (e.id.equalsIgnoreCase(id)) return e;
        return null;
    }

    public static Kind kindOf(Material m) {
        String n = m.name();
        if (n.endsWith("_PICKAXE")) return Kind.PICKAXE;
        if (n.endsWith("_AXE")) return Kind.AXE;
        if (n.endsWith("_SHOVEL")) return Kind.SHOVEL;
        if (n.endsWith("_HOE")) return Kind.HOE;
        if (n.endsWith("_SWORD")) return Kind.SWORD;
        if (m == Material.MACE) return Kind.MACE;
        if (n.endsWith("_HELMET")) return Kind.HELMET;
        if (n.endsWith("_CHESTPLATE")) return Kind.CHESTPLATE;
        if (n.endsWith("_LEGGINGS")) return Kind.LEGGINGS;
        if (n.endsWith("_BOOTS")) return Kind.BOOTS;
        return Kind.OTHER;
    }
}
