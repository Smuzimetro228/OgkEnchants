package ua.ogk.enchants;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Container;
import org.bukkit.block.data.Ageable;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDropItemEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.FurnaceRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

import static ua.ogk.enchants.EnchUtil.level;

public class BlockListener implements Listener {

    private final JavaPlugin plugin;
    private final List<FurnaceRecipe> furnace = new ArrayList<>();
    private boolean busy = false;

    public BlockListener(JavaPlugin plugin) {
        this.plugin = plugin;
        Iterator<Recipe> it = Bukkit.recipeIterator();
        while (it.hasNext()) {
            if (it.next() instanceof FurnaceRecipe fr) furnace.add(fr);
        }
    }

    private static boolean isCrop(Material m) {
        return m == Material.WHEAT || m == Material.CARROTS || m == Material.POTATOES
                || m == Material.BEETROOTS || m == Material.NETHER_WART;
    }

    private ItemStack smelt(ItemStack in) {
        for (FurnaceRecipe r : furnace) {
            if (r.getInputChoice().test(in)) {
                ItemStack out = r.getResult().clone();
                out.setAmount(Math.min(64, r.getResult().getAmount() * in.getAmount()));
                return out;
            }
        }
        return in;
    }

    private void give(Player p, ItemStack stack, Location at) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(stack);
        for (ItemStack l : left.values()) at.getWorld().dropItemNaturally(at, l);
    }

    // ---------- Бур: 3x3 ----------
    private List<Block> bur(Player p, Block b, ItemStack tool) {
        BlockFace f = p.getTargetBlockFace(8);
        if (f == null) f = BlockFace.UP;
        List<Block> out = new ArrayList<>();
        for (int a = -1; a <= 1; a++) {
            for (int c = -1; c <= 1; c++) {
                if (a == 0 && c == 0) continue;
                int dx = 0, dy = 0, dz = 0;
                if (f.getModY() != 0) { dx = a; dz = c; }
                else if (f.getModX() != 0) { dy = a; dz = c; }
                else { dx = a; dy = c; }
                Block x = b.getRelative(dx, dy, dz);
                if (canBreak(x, tool)) out.add(x);
            }
        }
        return out;
    }

    private boolean canBreak(Block x, ItemStack tool) {
        Material t = x.getType();
        if (t.isAir() || t.getHardness() < 0 || x.isLiquid()) return false;
        if (x.getState() instanceof Container) return false;
        return x.isPreferredTool(tool);
    }

    // ---------- Дровосек: до 16 колод ----------
    private List<Block> logs(Block start) {
        Set<Block> seen = new LinkedHashSet<>();
        Deque<Block> q = new ArrayDeque<>();
        seen.add(start);
        q.add(start);
        while (!q.isEmpty() && seen.size() < 16) {
            Block c = q.poll();
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++) {
                        if (seen.size() >= 16) break;
                        Block n = c.getRelative(dx, dy, dz);
                        if (!seen.contains(n) && Tag.LOGS.isTagged(n.getType())) {
                            seen.add(n);
                            q.add(n);
                        }
                    }
        }
        List<Block> out = new ArrayList<>(seen);
        out.remove(start);
        return out;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (busy) return;
        Player p = e.getPlayer();
        if (p.getGameMode() == GameMode.CREATIVE) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool.getType().isAir()) return;
        Block b = e.getBlock();

        // --- Фермер (мотика) ---
        int farm = level(tool, Ench.FERMER);
        if (farm > 0 && isCrop(b.getType()) && b.getBlockData() instanceof Ageable ag) {
            if (ag.getAge() < ag.getMaximumAge()) {
                e.setCancelled(true);
                p.sendActionBar(Component.text("Культура ще не виросла!", NamedTextColor.RED));
                return;
            }
            Material crop = b.getType();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (b.getType().isAir()) {
                    Material below = b.getRelative(BlockFace.DOWN).getType();
                    boolean ok = crop == Material.NETHER_WART ? below == Material.SOUL_SAND : below == Material.FARMLAND;
                    if (ok) b.setType(crop);
                }
            });
            p.damageItemStack(EquipmentSlot.HAND, farm); // чим вищий рівень, тим швидше ламається мотика
            return;
        }

        // --- Бур / Дровосек ---
        int bur = level(tool, Ench.BUR);
        int drov = level(tool, Ench.DROVOSEK);
        List<Block> extra = new ArrayList<>();
        if (bur > 0) extra = bur(p, b, tool);
        else if (drov > 0 && Tag.LOGS.isTagged(b.getType())) extra = logs(b);
        if (extra.isEmpty()) return;

        int smelt = level(tool, Ench.AVTOPLAVKA);
        int mag = level(tool, Ench.MAGNIT);
        int broken = 0;
        busy = true;
        try {
            for (Block x : extra) {
                if (x.getType().isAir()) continue;
                BlockBreakEvent ev = new BlockBreakEvent(x, p);
                Bukkit.getPluginManager().callEvent(ev); // повага до захисту регіонів
                if (ev.isCancelled()) continue;
                Collection<ItemStack> drops = x.getDrops(tool, p);
                Location loc = x.getLocation().add(0.5, 0.5, 0.5);
                x.setType(Material.AIR);
                for (ItemStack d : drops) {
                    if (smelt > 0) d = smelt(d);
                    if (mag > 0) give(p, d, p.getLocation());
                    else loc.getWorld().dropItemNaturally(loc, d);
                }
                broken++;
            }
        } finally {
            busy = false;
        }
        if (broken > 0) p.damageItemStack(EquipmentSlot.HAND, broken);
    }

    // ---------- Автоплавка + Магніт для основного блоку ----------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(BlockDropItemEvent e) {
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (tool.getType().isAir()) return;
        int smelt = level(tool, Ench.AVTOPLAVKA);
        int mag = level(tool, Ench.MAGNIT);
        if (smelt == 0 && mag == 0) return;

        if (smelt > 0) {
            for (Item it : e.getItems()) it.setItemStack(smelt(it.getItemStack()));
        }
        if (mag > 0) {
            for (Item it : e.getItems()) give(p, it.getItemStack(), p.getLocation());
            e.getItems().clear();
        }
    }

    // ---------- Лавохід ----------
    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedBlock()) return;
        Player p = e.getPlayer();
        int l = level(p.getInventory().getBoots(), Ench.LAVOHID);
        if (l == 0) return;
        int r = l + 1;
        Block base = p.getLocation().getBlock();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz > r * r) continue;
                for (int dy = -1; dy <= 0; dy++) {
                    Block b = base.getRelative(dx, dy, dz);
                    if (b.getType() == Material.LAVA) b.setType(Material.OBSIDIAN);
                }
            }
        }
    }
}
