package ua.ogk.enchants;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.concurrent.ThreadLocalRandom;

import static ua.ogk.enchants.EnchUtil.armorLevel;
import static ua.ogk.enchants.EnchUtil.level;

public class CombatListener implements Listener {

    private boolean busy = false;

    private static boolean roll(int percent) {
        return ThreadLocalRandom.current().nextInt(100) < percent;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (busy) return;

        // ---- Сталь: шанс 5 / 10 відсотків не отримати удар ----
        if (e.getEntity() instanceof Player target) {
            Entity d = e.getDamager();
            LivingEntity src = null;
            if (d instanceof LivingEntity le) src = le;
            else if (d instanceof Projectile pr && pr.getShooter() instanceof LivingEntity s) src = s;
            if (src != null) {
                int l = armorLevel(target, Ench.STAL);
                if (l > 0 && roll(5 * l)) {
                    e.setCancelled(true);
                    target.sendActionBar(Component.text("Сталь заблокувала удар!", NamedTextColor.GREEN));
                    return;
                }
            }
        }

        if (!(e.getDamager() instanceof Player p)) return;
        if (!(e.getEntity() instanceof LivingEntity victim)) return;
        ItemStack w = p.getInventory().getItemInMainHand();
        if (w.getType().isAir()) return;

        // ---- Оглушення: шанс 3 / 5 / 7 відсотків ----
        int og = level(w, Ench.OGKUSHENYA);
        if (og > 0 && roll(1 + 2 * og)) {
            victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 2));
            victim.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 20, 1));
            victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2));
        }

        // ---- Каратель: +15 відсотків шкоди за рівень ----
        int kar = level(w, Ench.KARATEL);
        if (kar > 0) e.setDamage(e.getDamage() * (1 + 0.15 * kar));

        // ---- Крушитель: +10 відсотків зносу броні за рівень ----
        int kr = level(w, Ench.KRUSHYTEL);
        if (kr > 0) {
            wear(victim, EquipmentSlot.HEAD, 10 * kr);
            wear(victim, EquipmentSlot.CHEST, 10 * kr);
            wear(victim, EquipmentSlot.LEGS, 10 * kr);
            wear(victim, EquipmentSlot.FEET, 10 * kr);
        }

        // ---- Булава: удар з висоти ----
        if (w.getType() == Material.MACE && p.getFallDistance() > 1.5f) {
            int pot = level(w, Ench.POTUZHNIST);
            if (pot > 0) {
                double r = 2 + pot;
                double dmg = e.getFinalDamage() * 0.5;
                busy = true;
                try {
                    for (Entity n : victim.getNearbyEntities(r, r, r)) {
                        if (n instanceof LivingEntity le && !(n instanceof ArmorStand) && n != p && n != victim) {
                            le.damage(dmg, p);
                        }
                    }
                } finally {
                    busy = false;
                }
            }
            if (level(w, Ench.STRUS) > 0) {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 2));
                victim.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 2));
            }
        }
    }

    private void wear(LivingEntity le, EquipmentSlot slot, int percent) {
        if (le.getEquipment() == null) return;
        ItemStack it = le.getEquipment().getItem(slot);
        if (it.getType().isAir()) return;
        if (roll(percent)) le.damageItemStack(slot, 1);
    }

    // ---- Фермер досвіду: множник досвіду з мобів (1.5 / 2 / 2.5) ----
    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(EntityDeathEvent e) {
        Player k = e.getEntity().getKiller();
        if (k == null) return;
        int l = level(k.getInventory().getItemInMainHand(), Ench.DOSVID);
        if (l > 0) e.setDroppedExp((int) Math.round(e.getDroppedExp() * (1 + 0.5 * l)));
    }
}
