package ua.ogk.enchants;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public final class OgkEnchants extends JavaPlugin implements TabExecutor {

    @Override
    public void onEnable() {
        EnchUtil.init(this);
        getServer().getPluginManager().registerEvents(new BlockListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(), this);
        getCommand("enchant").setExecutor(this);
        getCommand("enchant").setTabCompleter(this);
    }

    private void help(CommandSender s) {
        s.sendMessage("§6Використання: §e/enchant <чар> <рівень>");
        for (Ench e : Ench.values()) {
            s.sendMessage("§7- §e" + e.id + " §8(§f" + e.display + "§8) §7макс: §f" + e.max + " §8| §7" + e.hint);
        }
        s.sendMessage("§7Рівень §f0 §7знімає чар.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Тільки для гравців.");
            return true;
        }
        if (args.length == 0) {
            help(p);
            return true;
        }
        Ench e = Ench.byId(args[0]);
        if (e == null) {
            p.sendMessage("§cНевідомий чар: §7" + args[0]);
            help(p);
            return true;
        }
        ItemStack item = p.getInventory().getItemInMainHand();
        if (item.getType().isAir()) {
            p.sendMessage("§cВізьми предмет у руку!");
            return true;
        }
        if (!e.valid(item.getType())) {
            p.sendMessage("§cЦей чар не підходить для предмета! §7Підходить: §f" + e.hint);
            return true;
        }
        int lvl = 1;
        if (args.length > 1) {
            try {
                lvl = Integer.parseInt(args[1]);
            } catch (NumberFormatException ex) {
                p.sendMessage("§cРівень має бути числом від 0 до " + e.max + "!");
                return true;
            }
        }
        if (lvl < 0 || lvl > e.max) {
            p.sendMessage("§cРівень має бути від 0 до " + e.max + "!");
            return true;
        }
        EnchUtil.set(item, e, lvl);
        p.getInventory().setItemInMainHand(item);
        if (lvl > 0) p.sendMessage("§aЧар §7" + e.display + " " + EnchUtil.roman(lvl) + " §aнакладено!");
        else p.sendMessage("§aЧар §7" + e.display + " §aзнято!");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (Ench e : Ench.values()) {
                if (e.id.startsWith(args[0].toLowerCase())) out.add(e.id);
            }
        } else if (args.length == 2) {
            Ench e = Ench.byId(args[0]);
            if (e != null) {
                for (int i = 0; i <= e.max; i++) out.add(String.valueOf(i));
            }
        }
        return out;
    }
}
