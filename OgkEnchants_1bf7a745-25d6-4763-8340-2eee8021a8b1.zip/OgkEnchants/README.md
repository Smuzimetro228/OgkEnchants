# OgkEnchants (Paper 1.21+, Java 21)

## Збірка
- Локально: `mvn package` -> `target/OgkEnchants.jar`
- Онлайн (з телефона): завантаж папку в GitHub-репозиторій -> вкладка Actions -> Build -> Artifacts -> OgkEnchants.

Кинь jar у `plugins/`, команда: `/enchant <чар> <рівень>` (право `ogkushenya.admin`).
